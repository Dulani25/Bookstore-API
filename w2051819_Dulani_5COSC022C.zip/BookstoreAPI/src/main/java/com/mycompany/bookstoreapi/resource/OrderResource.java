/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resource;

/**
 *
 * @author dulanikamkanamge
 */
import com.mycompany.bookstoreapi.storage.Database;
import com.mycompany.bookstoreapi.model.Order;
import com.mycompany.bookstoreapi.model.CartItem;
import com.mycompany.bookstoreapi.model.Book;
import com.mycompany.bookstoreapi.exception.CustomerNotFoundException;
import com.mycompany.bookstoreapi.exception.CartNotFoundException;
import com.mycompany.bookstoreapi.exception.OutOfStockException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.ArrayList;

@Path("/customers/{customerId}/orders")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class OrderResource {

    @POST
    public Response createOrder(@PathParam("customerId") int customerId) {
        if (!Database.customers.containsKey(customerId)) {
            throw new CustomerNotFoundException("Customer not found");
        }
        List<CartItem> cart = Database.carts.get(customerId);
        if (cart == null || cart.isEmpty()) {
            throw new CartNotFoundException("Cart is empty");
        }

        double totalPrice = 0;
        for (CartItem item : cart) {
            Book book = Database.books.get(item.getBookId());
            if (book.getStock() < item.getQuantity()) {
                throw new OutOfStockException("Not enough stock for book: " + book.getTitle());
            }
            totalPrice += book.getPrice() * item.getQuantity();
            book.setStock(book.getStock() - item.getQuantity()); // reduce stock
        }

        Order order = new Order(Database.orderIdCounter++, customerId, new ArrayList<>(cart), totalPrice);
        List<Order> customerOrders = Database.orders.getOrDefault(customerId, new ArrayList<>());
        customerOrders.add(order);
        Database.orders.put(customerId, customerOrders);

        Database.carts.remove(customerId); // Empty the cart

        return Response.status(Response.Status.CREATED).entity(order).build();
    }

    @GET
    public List<Order> getAllOrders(@PathParam("customerId") int customerId) {
        if (!Database.customers.containsKey(customerId)) {
            throw new CustomerNotFoundException("Customer not found");
        }
        return Database.orders.getOrDefault(customerId, new ArrayList<>());
    }

    @GET
    @Path("/{orderId}")
    public Order getOrderById(@PathParam("customerId") int customerId, @PathParam("orderId") int orderId) {
        List<Order> customerOrders = Database.orders.get(customerId);
        if (customerOrders == null) {
            throw new CartNotFoundException("No orders found for this customer");
        }
        for (Order order : customerOrders) {
            if (order.getId() == orderId) {
                return order;
            }
        }
        throw new CartNotFoundException("Order not found with ID " + orderId);
    }
}

