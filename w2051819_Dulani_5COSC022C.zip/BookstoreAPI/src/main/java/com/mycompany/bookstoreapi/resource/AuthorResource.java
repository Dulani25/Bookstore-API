/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resource;

/**
 *
 * @author dulanikamkanamge
 */

import com.mycompany.bookstoreapi.model.Author;
import com.mycompany.bookstoreapi.model.Book;
import com.mycompany.bookstoreapi.storage.Database;
import com.mycompany.bookstoreapi.exception.AuthorNotFoundException;
import com.mycompany.bookstoreapi.exception.InvalidInputException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.ArrayList;

@Path("/authors")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class AuthorResource {

    @POST
    public Response createAuthor(Author author) {
        if (author.getName() == null || author.getName().isEmpty()) {
            throw new InvalidInputException("Author name cannot be empty");
        }
        author.setId(Database.authorIdCounter++);
        Database.authors.put(author.getId(), author);
        return Response.status(Response.Status.CREATED).entity(author).build();
    }

    @GET
    public List<Author> getAllAuthors() {
        return new ArrayList<>(Database.authors.values());
    }

    @GET
    @Path("/{id}")
    public Author getAuthor(@PathParam("id") int id) {
        Author author = Database.authors.get(id);
        if (author == null) {
            throw new AuthorNotFoundException("Author not found with ID " + id);
        }
        return author;
    }

    @PUT
    @Path("/{id}")
    public Author updateAuthor(@PathParam("id") int id, Author updatedAuthor) {
        Author author = Database.authors.get(id);
        if (author == null) {
            throw new AuthorNotFoundException("Author not found with ID " + id);
        }
        updatedAuthor.setId(id);
        Database.authors.put(id, updatedAuthor);
        return updatedAuthor;
    }

    @DELETE
    @Path("/{id}")
    public Response deleteAuthor(@PathParam("id") int id) {
        Author author = Database.authors.remove(id);
        if (author == null) {
            throw new AuthorNotFoundException("Author not found with ID " + id);
        }
        return Response.noContent().build();
    }

    @GET
    @Path("/{id}/books")
    public List<Book> getBooksByAuthor(@PathParam("id") int id) {
        if (!Database.authors.containsKey(id)) {
            throw new AuthorNotFoundException("Author not found with ID " + id);
        }
        List<Book> books = new ArrayList<>();
        for (Book book : Database.books.values()) {
            if (book.getAuthorId() == id) {
                books.add(book);
            }
        }
        return books;
    }
}
