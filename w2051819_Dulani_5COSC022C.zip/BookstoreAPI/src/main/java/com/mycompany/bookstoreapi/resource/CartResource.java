/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resource;

/**
 *
 * @author dulanikamkanamge
 */
import com.mycompany.bookstoreapi.storage.Database;
import com.mycompany.bookstoreapi.model.CartItem;
import com.mycompany.bookstoreapi.model.Book;
import com.mycompany.bookstoreapi.exception.CartNotFoundException;
import com.mycompany.bookstoreapi.exception.CustomerNotFoundException;
import com.mycompany.bookstoreapi.exception.BookNotFoundException;
import com.mycompany.bookstoreapi.exception.InvalidInputException;
import com.mycompany.bookstoreapi.exception.OutOfStockException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;
import java.util.ArrayList;

@Path("/customers/{customerId}/cart")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CartResource {

    @POST
    @Path("/items")
    public Response addItem(@PathParam("customerId") int customerId, CartItem item) {
        if (!Database.customers.containsKey(customerId)) {
            throw new CustomerNotFoundException("Customer not found");
        }
        Book book = Database.books.get(item.getBookId());
        if (book == null) {
            throw new BookNotFoundException("Book not found");
        }
        if (book.getStock() < item.getQuantity()) {
            throw new OutOfStockException("Not enough stock");
        }

        List<CartItem> cart = Database.carts.getOrDefault(customerId, new ArrayList<>());
        cart.add(item);
        Database.carts.put(customerId, cart);
        return Response.status(Response.Status.CREATED).entity(cart).build();
    }

    @GET
    public List<CartItem> getCart(@PathParam("customerId") int customerId) {
        List<CartItem> cart = Database.carts.get(customerId);
        if (cart == null) {
            throw new CartNotFoundException("Cart not found for customer " + customerId);
        }
        return cart;
    }

    @PUT
    @Path("/items/{bookId}")
    public Response updateItem(@PathParam("customerId") int customerId, @PathParam("bookId") int bookId, CartItem updatedItem) {
        List<CartItem> cart = Database.carts.get(customerId);
        if (cart == null) {
            throw new CartNotFoundException("Cart not found");
        }
        boolean found = false;
        for (CartItem item : cart) {
            if (item.getBookId() == bookId) {
                item.setQuantity(updatedItem.getQuantity());
                found = true;
                break;
            }
        }
        if (!found) {
            throw new BookNotFoundException("Book not found in cart");
        }
        return Response.ok(cart).build();
    }

    @DELETE
    @Path("/items/{bookId}")
    public Response deleteItem(@PathParam("customerId") int customerId, @PathParam("bookId") int bookId) {
        List<CartItem> cart = Database.carts.get(customerId);
        if (cart == null) {
            throw new CartNotFoundException("Cart not found");
        }
        cart.removeIf(item -> item.getBookId() == bookId);
        return Response.noContent().build();
    }
}

