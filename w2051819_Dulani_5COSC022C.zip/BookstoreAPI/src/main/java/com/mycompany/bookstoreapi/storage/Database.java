/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.storage;

/**
 *
 * @author dulanikamkanamge
 */
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.mycompany.bookstoreapi.model.Book;
import com.mycompany.bookstoreapi.model.Author;
import com.mycompany.bookstoreapi.model.Customer;
import com.mycompany.bookstoreapi.model.CartItem;
import com.mycompany.bookstoreapi.model.Order;

public class Database {
    public static Map<Integer, Book> books = new HashMap<>();
    public static Map<Integer, Author> authors = new HashMap<>();
    public static Map<Integer, Customer> customers = new HashMap<>();
    public static Map<Integer, List<CartItem>> carts = new HashMap<>();
    public static Map<Integer, List<Order>> orders = new HashMap<>();

    public static int bookIdCounter = 1;
    public static int authorIdCounter = 1;
    public static int customerIdCounter = 1;
    public static int orderIdCounter = 1;
}