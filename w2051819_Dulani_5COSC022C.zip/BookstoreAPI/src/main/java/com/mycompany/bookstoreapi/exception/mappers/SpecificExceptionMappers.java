/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.exception.mappers;

/**
 *
 * @author dulanikamkanamge
 */
import com.mycompany.bookstoreapi.exception.AuthorNotFoundException;
import com.mycompany.bookstoreapi.exception.BookNotFoundException;
import com.mycompany.bookstoreapi.exception.CustomerNotFoundException;
import com.mycompany.bookstoreapi.exception.CartNotFoundException;
import com.mycompany.bookstoreapi.exception.OutOfStockException;
import com.mycompany.bookstoreapi.exception.InvalidInputException;

import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;
import java.util.HashMap;
import java.util.Map;

@Provider
public class SpecificExceptionMappers {

    @Provider
    public static class BookNotFoundMapper implements ExceptionMapper<BookNotFoundException> {
        public Response toResponse(BookNotFoundException e) {
            return errorResponse(404, "Book Not Found", e.getMessage());
        }
    }

    @Provider
    public static class AuthorNotFoundMapper implements ExceptionMapper<AuthorNotFoundException> {
        public Response toResponse(AuthorNotFoundException e) {
            return errorResponse(404, "Author Not Found", e.getMessage());
        }
    }

    @Provider
    public static class CustomerNotFoundMapper implements ExceptionMapper<CustomerNotFoundException> {
        public Response toResponse(CustomerNotFoundException e) {
            return errorResponse(404, "Customer Not Found", e.getMessage());
        }
    }

    @Provider
    public static class InvalidInputMapper implements ExceptionMapper<InvalidInputException> {
        public Response toResponse(InvalidInputException e) {
            return errorResponse(400, "Invalid Input", e.getMessage());
        }
    }

    @Provider
    public static class OutOfStockMapper implements ExceptionMapper<OutOfStockException> {
        public Response toResponse(OutOfStockException e) {
            return errorResponse(400, "Out of Stock", e.getMessage());
        }
    }

    @Provider
    public static class CartNotFoundMapper implements ExceptionMapper<CartNotFoundException> {
        public Response toResponse(CartNotFoundException e) {
            return errorResponse(404, "Cart Not Found", e.getMessage());
        }
    }

    private static Response errorResponse(int status, String error, String message) {
        Map<String, String> body = new HashMap<>();
        body.put("error", error);
        body.put("message", message);

        return Response.status(status).entity(body).build();
    }
}
