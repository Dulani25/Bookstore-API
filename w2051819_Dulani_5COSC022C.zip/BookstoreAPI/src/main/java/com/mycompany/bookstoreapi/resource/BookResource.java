/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resource;

/**
 *
 * @author dulanikamkanamge
 */
import com.mycompany.bookstoreapi.model.Book;
import com.mycompany.bookstoreapi.storage.Database;
import com.mycompany.bookstoreapi.exception.BookNotFoundException;
import com.mycompany.bookstoreapi.exception.InvalidInputException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

@Path("/books")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class BookResource {

    @POST
    public Response createBook(Book book) {
        if (Database.authors.get(book.getAuthorId()) == null) {
            throw new InvalidInputException("Author ID does not exist");
        }
        book.setId(Database.bookIdCounter++);
        Database.books.put(book.getId(), book);
        return Response.status(Response.Status.CREATED).entity(book).build();
    }

    @GET
    public List<Book> getAllBooks() {
        return new ArrayList<>(Database.books.values());
    }

    @GET
    @Path("/{id}")
    public Book getBook(@PathParam("id") int id) {
        Book book = Database.books.get(id);
        if (book == null) {
            throw new BookNotFoundException("Book not found with ID " + id);
        }
        return book;
    }

    @PUT
    @Path("/{id}")
    public Book updateBook(@PathParam("id") int id, Book updatedBook) {
        Book existingBook = Database.books.get(id);
        if (existingBook == null) {
            throw new BookNotFoundException("Book not found with ID " + id);
        }
        updatedBook.setId(id);
        Database.books.put(id, updatedBook);
        return updatedBook;
    }

    @DELETE
    @Path("/{id}")
    public Response deleteBook(@PathParam("id") int id) {
        Book book = Database.books.remove(id);
        if (book == null) {
            throw new BookNotFoundException("Book not found with ID " + id);
        }
        return Response.noContent().build();
    }
}

