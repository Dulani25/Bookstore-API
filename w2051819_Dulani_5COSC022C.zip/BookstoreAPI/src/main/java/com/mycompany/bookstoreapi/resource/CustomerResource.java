/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.bookstoreapi.resource;

/**
 *
 * @author dulanikamkanamge
 */
import com.mycompany.bookstoreapi.model.Customer;
import com.mycompany.bookstoreapi.storage.Database;
import com.mycompany.bookstoreapi.exception.CustomerNotFoundException;
import com.mycompany.bookstoreapi.exception.InvalidInputException;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

@Path("/customers")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class CustomerResource {

    @POST
    public Response createCustomer(Customer customer) {
        if (customer.getName() == null || customer.getEmail() == null || customer.getPassword() == null) {
            throw new InvalidInputException("Customer information missing");
        }
        customer.setId(Database.customerIdCounter++);
        Database.customers.put(customer.getId(), customer);
        return Response.status(Response.Status.CREATED).entity(customer).build();
    }

    @GET
    public List<Customer> getAllCustomers() {
        return new ArrayList<>(Database.customers.values());
    }

    @GET
    @Path("/{id}")
    public Customer getCustomer(@PathParam("id") int id) {
        Customer customer = Database.customers.get(id);
        if (customer == null) {
            throw new CustomerNotFoundException("Customer not found with ID " + id);
        }
        return customer;
    }

    @PUT
    @Path("/{id}")
    public Customer updateCustomer(@PathParam("id") int id, Customer updatedCustomer) {
        Customer existingCustomer = Database.customers.get(id);
        if (existingCustomer == null) {
            throw new CustomerNotFoundException("Customer not found with ID " + id);
        }
        updatedCustomer.setId(id);
        Database.customers.put(id, updatedCustomer);
        return updatedCustomer;
    }

    @DELETE
    @Path("/{id}")
    public Response deleteCustomer(@PathParam("id") int id) {
        Customer customer = Database.customers.remove(id);
        if (customer == null) {
            throw new CustomerNotFoundException("Customer not found with ID " + id);
        }
        return Response.noContent().build();
    }
}

